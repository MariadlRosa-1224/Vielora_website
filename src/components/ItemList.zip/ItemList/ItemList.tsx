import {useState, useEffect} from "react";
import ItemCard from "../ItemCard/Itemcard";
import styles from './ItemList.module.scss';
import { useFetch } from "../useFetch/useFetch";
import { Loader } from '@mantine/core';

type ItemListProps = {
    search: string;
};

interface UrlResponse {
    results: Array<{name: string}>;
}

interface pokemonResponse {
    name: string;
    sprites: {
        front_default: string;
    };
    types: Array<{
        type: {
            name: string;
        };
    }>;
}


const ItemList = ({ search }: ItemListProps) => {
    const [items, setItems] = useState<Array<{name: string, image: string, category: string}>>([]);

    const {data, isLoading, error} = useFetch<UrlResponse>("https://pokeapi.co/api/v2/pokemon");

    useEffect(() => {
        if (data && Array.isArray(data.results)) {
            setItems([]);
            data.results.forEach(async (item) => {
                try {
                    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${item.name}`);
                    const itemData: pokemonResponse = await response.json();
                    setItems(prevItems => [
                        ...prevItems,
                        {
                            name: itemData.name,
                            image: itemData.sprites.front_default,
                            category: itemData.types[0].type.name
                        }
                    ]);
                } catch (err) {
                    console.error(`Failed to fetch data for item ${item.name}:`, err);
                }
            });
        }
    }, [data]);

    if (isLoading) {
        return   <div><Loader color="violet" size="lg" type="bars" /></div>;
    }
    if (error) {
        return <div>Error: {error.message}</div>;
    }




    const query = search.trim().toLowerCase();
    const filteredItems = query
        ? items.filter((item) => item.name.toLowerCase().includes(query))
        : items;


    return (
        <div className={styles.ItemList}>
            {filteredItems.map((item, index) => (
                <ItemCard 
                    key={index} 
                    name={item.name} 
                    image={item.image} 
                    category={item.category} 
                />
            ))}
        </div>


    );

}

export default ItemList;