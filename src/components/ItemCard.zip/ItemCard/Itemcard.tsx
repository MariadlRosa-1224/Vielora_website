import React, { useState, useEffect } from 'react';
import styles from './ItemCard.module.scss';

interface ItemCardProps {
    name: string;
    image: string;
    category: string;
}

const ItemCard: React.FC<ItemCardProps> = ({ name, image , category}) => {


    const [isHovered, setIsHovered] = useState(false);

    return (

        <div
            className={styles.ItemCard}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}

            
        >

        <div className={styles.overlay}></div> 
        <div className={styles.background} style={{backgroundImage: `url(${image})`}}></div> 
            
        <div className={styles.content}> 
            <span>{name}</span>
            <hr />
            <p>{category}</p>
             </div>

        </div>
    );
};

export default ItemCard;


