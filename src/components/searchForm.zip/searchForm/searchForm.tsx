import React from 'react';
import styles from './searchForm.module.scss';
import { AlphaSlider } from '@mantine/core';
import { useFetch } from '../useFetch/useFetch';

interface SearchFormProps {
    search: string;
    setSearch: (search: string) => void;
    category?: string;
}

function chosenCategory(category: string) {
    const locations = ['Anywhere', 'Plains', 'caves', 'Desert', 'Forest', 'Mountains', 'Ocean', 'Ruins', 'Sky']
    const ranks = ['All','D', 'C', 'B', 'A', 'S']
    const rarirties = ['All','Common', 'Uncommon', 'Rare', 'Special', 'Legendary', 'Mythical']
    const tameability = ['All','Easy', 'Medium', 'Hard', 'Untameable']


    switch (category) {
        case 'All':
            return (<>
            </>);
        case 'Fauna':
            return (
                <>
                <label htmlFor="location">Location</label>
                <select name='location' id='location'>
                    {locations.map((location, index) => (
                        <option key={index} value={location}>{location}</option>
                    ))}
                </select>
    
                <label htmlFor="dangerLevel">Danger Level</label>
                <select name="dangerLevel" id="dangerLevel">
                <option value=''>All</option>
                {Array.from({ length: 16 }, (_, i) => (
                <option key={i} value={i}>{i}</option>
                    ))}
                </select>
    
                <label htmlFor="rarity">Rarity</label>
                <select name="rarity" id="rarity">
                    {rarirties.map((rarity, index) => (
                        <option key={index} value={rarity === 'All' ? '' : rarity}>{rarity}</option>
                    ))}
                </select>

                <label htmlFor="tameability">Tameability</label>
                <select name="tameability" id="tameability">
                    {tameability.map((tame, index) => (
                        <option key={index} value={tame === 'All' ? '' : tame}>{tame}</option>
                    ))}
                </select>
                </>
            );
        case 'Flora':
            return (<>
                <label htmlFor="location">Location</label>
                <select name='location' id='location'>
                    {locations.map((location, index) => (
                        <option key={index} value={location}>{location}</option>
                    ))}
                </select>

                <label htmlFor="rarity">Rarity</label>
                    <select name="rarity" id="rarity">
                        {rarirties.map((rarity, index) => (
                            <option key={index} value={rarity === 'All' ? '' : rarity}>{rarity}</option>
                        ))}
                </select>
            </>);
        case 'Spells':
            return (<>
            <label htmlFor="rank">Rank</label>
            <select name="rank" id="rank">
                {ranks.map((rank, index) => (
                    <option key={index} value={rank === 'All' ? '' : rank}>{rank}</option>
                ))}
            </select>

            <label htmlFor="type">Type</label>
            <select name="type" id="type">
                <option value=''>All</option>
                <option value='phonic'>Phonic</option>
            </select>
            </>);
        case 'Techniques':
            return (<>     
            <label htmlFor="rank">Rank</label>       
            <select name="rank" id="rank">
                {ranks.map((rank, index) => (
                    <option key={index} value={rank === 'All' ? '' : rank}>{rank}</option>
                ))}
            </select></>);
        case 'Runes':
            return (<>     
            <label htmlFor="rank">Rank</label>       
            <select name="rank" id="rank">
                {ranks.map((rank, index) => (
                    <option key={index} value={rank === 'All' ? '' : rank}>{rank}</option>
                ))}
            </select></>);
        case 'Items':
            return (<>
                <label htmlFor="rarity">Rarity</label>
                <select name="rarity" id="rarity">
                    {rarirties.map((rarity, index) => (
                        <option key={index} value={rarity === 'All' ? '' : rarity}>{rarity}</option>
                    ))}
                </select>
            </>);
        case 'Potions':
            return (<>
                <label htmlFor="rarity">Rarity</label>
                <select name="rarity" id="rarity">
                   {rarirties.map((rarity, index) => (
                        <option key={index} value={rarity === 'All' ? '' : rarity}>{rarity}</option>
                    ))}
                </select>
            </>);
        default:
            return 'All';
    }
}



const SearchBar: React.FC<SearchFormProps> = ({search, setSearch}) => {


    const categories = ['All','Fauna', 'Flora', 'Spells', 'Techniques', 'Runes', 'Items', 'Potions'];
    const [category, setCategory] = React.useState('All');
    

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
    };

    return (
        <div className={styles.searchForm}>
            <form onSubmit={handleSubmit}>
            <label htmlFor="search">Search</label>
            <input type='text'
             value={search}
            placeholder='Search'
            onChange={(e) => setSearch(e.target.value)} />

            
            <label htmlFor="category">Category</label>
            <select name='category' id='category'
            onChange={(e) => setCategory(e.target.value)}>
                {categories.map((category, index) => (
                    <option key={index} value={category}>{category}</option>
                ))}
            </select>

            {chosenCategory(category)}






            <button type='submit'>Search</button>
            </form>
        </div>
    );
}

export default SearchBar;

