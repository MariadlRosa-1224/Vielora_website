import React, { useState, useEffect,  ReactNode } from 'react';
import styles from './GeneralContentContainer.module.scss';

interface GeneralContentContainerProps{
     newwidth: string;
     newheight: string;
     children: ReactNode;
}

const GeneralContentContainer: React.FC<GeneralContentContainerProps> = ({newwidth, newheight, children}) => {
    return (
        <section className={styles.GeneralContentContainer} style={{width: newwidth, height: newheight}}>
            {children}
        </section>
    );

}

export default GeneralContentContainer